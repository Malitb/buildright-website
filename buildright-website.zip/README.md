# BuildRight Construction & Consulting Website

A modern, responsive single-page website for construction and consulting services.

## Features

- Fully responsive design (desktop, tablet, mobile)
- Smooth scroll animations and transitions
- Interactive contact form
- Auto-rotating testimonials slider
- Animated statistics counter
- Mobile navigation menu

## How to Deploy to GitHub Pages

### Step 1: Create a GitHub Repository
1. Go to [github.com](https://github.com) and sign in (or create an account)
2. Click the **+** icon in the top right → **New repository**
3. Name it `buildright-website` (or any name you prefer)
4. Make it **Public**
5. Click **Create repository**

### Step 2: Upload the Files
**Option A - Using GitHub Web Interface:**
1. In your new repo, click **"uploading an existing file"**
2. Drag and drop the `index.html` file
3. Click **Commit changes**

**Option B - Using Git Command Line:**
```bash
git clone https://github.com/YOUR_USERNAME/buildright-website.git
cd buildright-website
cp /path/to/index.html .
git add index.html
git commit -m "Initial commit"
git push origin main
```

### Step 3: Enable GitHub Pages
1. In your repository, go to **Settings** (tab at the top)
2. Scroll down to **Pages** in the left sidebar
3. Under **Source**, select **Deploy from a branch**
4. Select **main** branch and **/(root)** folder
5. Click **Save**
6. Wait 1-2 minutes, then visit: `https://YOUR_USERNAME.github.io/buildright-website`

## Live URL
Once deployed, your site will be available at:
```
https://YOUR_USERNAME.github.io/buildright-website
```

## Custom Domain (Optional)
To use your own domain (e.g., buildright.com):
1. Buy a domain from Namecheap, GoDaddy, or Cloudflare
2. In your repo's **Settings → Pages**, add your custom domain
3. Configure DNS records with your domain provider
4. Enable HTTPS (GitHub does this automatically)

## Technologies Used
- HTML5
- CSS3 (Grid, Flexbox, Custom Properties)
- Vanilla JavaScript (no frameworks)
- Lucide Icons
- Google Fonts (Inter + Playfair Display)
